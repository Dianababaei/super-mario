package model.enemy;

import java.awt.image.BufferedImage;

public class Flower extends Enemy {
    public Flower(double x, double y, BufferedImage style) {
        super(x, y, style);
    }
}
