package model.brick;

import manager.GameEngine;
import model.brick.Brick;
import model.enemy.Enemy;

import java.awt.image.BufferedImage;

public class CheckPoint  extends Brick {


    public CheckPoint(double x, double y, BufferedImage style) {
        super(x, y, style);

    }


    }


