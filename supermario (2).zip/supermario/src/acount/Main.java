package acount;

public class Main {
    public static void main(String[] args) {
        SignUp f = new SignUp();
    }
}